# this is R code for performing fitting a phenomenological viral load model to CMV DNA data for GMUH cohort using bayesian hierarchical modelling
# It calls the stan file "cmv_DNA_model_multilevel.stan" which implement the Bayesian hirarchical modelling
rm(list=ls())  # clear memory
# ===========  Load R libraries (install them before loading) ====================
library(rstan)
library(tidyverse)
library(bayesplot)
library(deSolve)

# ===========  load clinical data ===============

V_data = read.csv("CMV_DNA_of_GMUH20201124.csv")
filtered_V_data = V_data[(V_data$days %in% c(0:180)),]
for (i in 1:length(filtered_V_data$No)){
  temp = filtered_V_data$cmvDNA[filtered_V_data$No %in% filtered_V_data$No[i]]
  if (max(temp)>1000 & length(temp[temp>500])>1){filtered_V_data$Vgroup[i] = 1}
  else {filtered_V_data$Vgroup[i] = 0}
}

filtered_V_data1 = filtered_V_data[filtered_V_data$Vgroup %in% c(1),]
ID_selected = unname(sapply(unique(filtered_V_data1$No), as.character))

'%nin%' = Negate('%in%')
ID_selected = ID_selected[ID_selected %nin% c('b74')] # removed because of reoccurence in 90 days post-HSCT 

selected_V_data = filtered_V_data[(filtered_V_data$No %in% ID_selected),]

nObs_Vdata = length(selected_V_data$cmvDNA)
startV = (1:nObs_Vdata)[!duplicated(selected_V_data$No)]
endV = c(startV[-1] - 1, nObs_Vdata)
         
# define data list 
data_combined = list(num_pts = 181,
                     nObs_Vdata = length(selected_V_data$cmvDNA),
                     nPar=4,  # number of non-fixed model parameters 
                     nPatients = length(ID_selected),   # number of patients selected
                     time_Vdata = selected_V_data$days,
                     log_Vdata = log(selected_V_data$cmvDNA),
                     startV = (1:nObs_Vdata)[!duplicated(selected_V_data$No)],
                     endV = c(startV[-1] - 1, nObs_Vdata),
                     l = c(0, 1, 1, 0),
                     u = c(10, 200, 200, 10),
                     V0 = 500,
                     t0 = 0)

# =========== choose initial estimates ===========

set.seed(12345)   # set random seed for reproducibility

inits = list()
No_of_chains = 4
for (i in 1:No_of_chains){
  inits1 = list(theta = c(runif(1,data_combined$l[1],data_combined$u[1]),
                          runif(1,data_combined$l[2],data_combined$u[2]),
                          runif(1,data_combined$l[3],data_combined$u[3]),
                          runif(1,data_combined$l[4],data_combined$u[4])),
                epsilonV = 1,
                L = diag(data_combined$nPar),    # initial choice for the lower Cholesky factor of the correlation matrix L
                s = matrix(rep(0, data_combined$nPar * data_combined$nPatients), nrow = data_combined$nPar),   # inital choice for the standard multivariate normal distribution s
                omega = c(1,1,1,1)/10)
  
  inits[[i]] = inits1
}

options(mc.cores=parallel::detectCores()) # to utilise all cores available in your computer

# model fitting 
fitting_results = stan("cmv_DNA_model_multilevel.stan",
                       data = data_combined,
                       pars = c("theta", "theta_i"),
                       seed = 202009,  # set random seed for reproducibility
                       iter = 2000,
                       chains = No_of_chains,
                       warmup = 1000,
                       init = inits,
                       control = list(adapt_delta = 0.99, max_treedepth = 15)) 

# show summary result
print(fitting_results)

# save.image(file = "multilevel_fitting_results_GMUH_CMV_DNA.RData")

# extract posterior samples for population mean parameters
posterior_samples_all = rstan::extract(fitting_results, pars = c("theta"), inc_warmup = TRUE, permuted = FALSE)
posterior_samples_merged_after_burnin = rstan::extract(fitting_results, pars = c("theta"))

# show markov chains
color_scheme_set("brewer-Spectral")
mcmc_trace(posterior_samples_all, n_warmup = 1000,
           facet_args = list(nrow = 2, labeller = label_parsed))

# show marginal posterior distributions for population mean parameters
posterior_sample_table = data.frame(pV_popmean = posterior_samples_merged_after_burnin$theta[,1],
                                    LV1_popmean = posterior_samples_merged_after_burnin$theta[,2],
                                    LV2_popmean = posterior_samples_merged_after_burnin$theta[,3],
                                    c_popmean = posterior_samples_merged_after_burnin$theta[,4])

ggplot(posterior_sample_table, aes(x=pV_popmean)) +
  geom_histogram(breaks=seq(0,10,10/30))
quantile(posterior_sample_table$pV_popmean, probs = c(0.025, 0.5, 0.975))

ggplot(posterior_sample_table, aes(x=LV1_popmean)) +
  geom_histogram(breaks=seq(30,50,20/30))
quantile(posterior_sample_table$LV1_popmean, probs = c(0.025, 0.5, 0.975))

ggplot(posterior_sample_table, aes(x=LV2_popmean)) +
  geom_histogram(breaks=seq(35,55,20/30))
quantile(posterior_sample_table$LV2_popmean, probs = c(0.025, 0.5, 0.975))

ggplot(posterior_sample_table, aes(x=c_popmean)) +
  geom_histogram(breaks=seq(0,7,7/30))
quantile(posterior_sample_table$c_popmean, probs = c(0.025, 0.5, 0.975))

# posterior predictive check
cmv_model = function(t, y, param){
  dydt = param[1]*(t^9/(t^9+param[2]^9))*(param[3]^9/(t^9+param[3]^9))*y+param[4]*(param[5]-y);
  list(c(dydt))
}

# show the model fits of the viral load and CD8+ T cell data for individual patients
posterior_individuals = rstan::extract(fitting_results, pars = c("theta_i"))

for (j in 1:length(ID_selected)){  # patient number (not ID) 
  
  t_ppc = seq(0, 180, 1)
  
  V_ppc = matrix(, nrow = 4000, ncol = length(t_ppc))
  V_lower_95PI = t_ppc
  V_median_95PI = t_ppc
  V_upper_95PI = t_ppc
  
  for (i in 1:4000){
    y_init = 500
    param_fit = c(posterior_individuals$theta_i[i,1,j], posterior_individuals$theta_i[i,2,j],posterior_individuals$theta_i[i,3,j],posterior_individuals$theta_i[i,4,j],500)
    model_output = ode(times = t_ppc, y = y_init, func = cmv_model, parms = param_fit, method = "bdf")
    V_ppc[i,] = model_output[,2]
  }
  
  for (i in 1:length(t_ppc)){
    temp1 = quantile(V_ppc[,i], probs = c(0.025, 0.5, 0.975))
    V_lower_95PI[i] = temp1[1]
    V_median_95PI[i] = temp1[2]
    V_upper_95PI[i] = temp1[3]
  }
  
  data_plot_V = data.frame(timeV = data_combined$time_Vdata[startV[j]:endV[j]],
                           data_V = selected_V_data$cmvDNA[startV[j]:endV[j]])
  
  fit_plot = data.frame(time = t_ppc,
                        V_lower_95PI = V_lower_95PI,
                        V_median_95PI = V_median_95PI,
                        V_upper_95PI = V_upper_95PI)
  
  selected_V_data$Patient1 = sapply(selected_V_data$Patient, as.character)
  patient_name = unique(selected_V_data$Patient1[selected_V_data$No %in% ID_selected])
  
  plot_V = ggplot()+
    geom_point(data = data_plot_V, aes(timeV, data_V), size = 3) +
    geom_line(data = fit_plot, aes(time, V_median_95PI)) +
    geom_ribbon(aes(x = fit_plot$time, ymin = V_lower_95PI, ymax = V_upper_95PI), alpha = 0.5) +
    scale_y_continuous(trans='log10') +
    scale_x_continuous(breaks=seq(0,180,30)) +
    coord_cartesian(xlim = c(0,180), ylim = c(1e+2,1e+6)) +
    theme_bw() +
    theme(axis.text=element_text(size=15)) +
    xlab("time (days)") +
    ylab("V")
  
  jpeg(paste0("Fit_ID_", ID_selected[j], ".jpg"))
  print(plot_V)
  dev.off()
}


