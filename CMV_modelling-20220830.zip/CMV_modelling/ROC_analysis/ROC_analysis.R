# this R code conducts ROC analysis on the data absed on which we proposed a CD8 T cell threshold for predicting the disease progression 
library(caTools)

rm(list = ls())
############################## ROC ##############################
V_data_GFPH = read.csv("CMV_DNA_of_GFPU20201021.csv")
T_data_GFPH = read.csv("Tcell_of_GFPU20201021.csv")
V_data_GMUH = read.csv("CMV_DNA_of_GMUH20201124.csv")
T_data_GMUH = read.csv("Tcell_of_GMUH20201124.csv")

V_data = rbind(V_data_GFPH[,1:4],V_data_GMUH[,1:4])

V_data$status[1] = 0
k = 0
for (i in 2:length(V_data$No)){
  if (V_data$No[i] != V_data$No[i-1]) {k = 0}
  if (V_data$cmvDNA[i] > 500) {k = 1}
  V_data$status[i] = k
}

V_data = V_data[(!is.na(V_data$cmvDNA) & V_data$days %in% c(0:2000) & V_data$status %in% c(1)),]

T_data = rbind(T_data_GFPH[,1:4],T_data_GMUH[,1:4]) 
T_data = T_data[(!is.na(T_data$CD8) & T_data$days %in% c(0:2000)),]


for (i in 1:length(T_data$CD8)){
  temp = V_data$cmvDNA[(V_data$No %in% c(T_data$No[i]) & V_data$days %in% c((T_data$days[i]-3):(T_data$days[i]+3)))]
  if (length(temp)==0){T_data$Vgroup[i] = 0}
  else {T_data$Vgroup[i] = 1}
}

T_data_filtered = T_data[T_data$Vgroup %in% c(1),]

for (i in 1:length(T_data_filtered$No)){
  temp_V = V_data$cmvDNA[(V_data$No %in% c(T_data_filtered$No[i]) & V_data$days %in% c((T_data_filtered$days[i]-3):(T_data_filtered$days[i]+3)))]
  temp_days = V_data$days[(V_data$No %in% c(T_data_filtered$No[i]) & V_data$days %in% c((T_data_filtered$days[i]-3):(T_data_filtered$days[i]+3)))]
  ind_selected = which(abs(temp_days-T_data_filtered$days[i])==min(abs(temp_days-T_data_filtered$days[i])))
  T_data_filtered$cmvDNA[i] = temp_V[ind_selected[length(ind_selected)]]
}

roc_used = T_data_filtered[,c(1:4,6)]

threshold_all = c(0,1e-6,1e-5,1e-4,1e-3,1e-2,1e-1,seq(0.2,0.9,0.1),1:50000)
sensitivity = threshold_all
specificity = threshold_all

for (j in 1:length(threshold_all)){
  threshold = threshold_all[j]
  
  for (i in 1:length(roc_used$No)){
    if (roc_used$CD8[i] >= threshold & roc_used$cmvDNA[i] == 500){roc_used$result[i] = 'TN'}
    else if (roc_used$CD8[i] >= threshold & roc_used$cmvDNA[i] > 500){roc_used$result[i] = 'FN'}
    else if (roc_used$CD8[i] < threshold & roc_used$cmvDNA[i] > 500){roc_used$result[i] = 'TP'}
    else {roc_used$result[i] = 'FP'}
  }
  TP_num = length(roc_used$result[roc_used$result %in% c('TP')])
  TN_num = length(roc_used$result[roc_used$result %in% c('TN')])
  FP_num = length(roc_used$result[roc_used$result %in% c('FP')])
  FN_num = length(roc_used$result[roc_used$result %in% c('FN')])
  
  sensitivity[j] = TP_num/(TP_num+FN_num)
  specificity[j] = TN_num/(TN_num+FP_num)
}

youden_index = sensitivity+specificity-1

FPR = sort(1-specificity)
trapz(FPR,sort(sensitivity))

tiff("roc.tiff", height = 13, width = 15, units = 'cm', 
     compression = "lzw", res = 300)
plot(1-specificity,sensitivity,type="b",xlim=c(0, 1), ylim=c(0, 1), panel.first = grid())
lines(seq(0,1,0.01),seq(0,1,0.01),col="black")
dev.off()

tiff("Case_distribution.tiff", height = 13, width = 15, units = 'cm', 
     compression = "lzw", res = 300)
par(mfrow=c(2,1), mai=c(0.9,0.9,0.2,0.1))
hist(log10(roc_used$CD8[roc_used$result %in% c('TP','FN')]), breaks = seq(-1,6,0.5), main = '', xlab = '', ylab = 'DNA positive')
hist(log10(roc_used$CD8[roc_used$result %in% c('TN','FP')]), breaks = seq(-1,6,0.5), main = '', xlab = 'log10(CD8 T cells)', ylab = 'DNA negative')
dev.off()

tiff("sensitivity_vs_threshold.tiff", height = 13, width = 15, units = 'cm', 
     compression = "lzw", res = 300)
plot(threshold_all,sensitivity,type="b",xlim=c(0, 4e+3), ylim=c(0, 1), panel.first = grid())
dev.off()
