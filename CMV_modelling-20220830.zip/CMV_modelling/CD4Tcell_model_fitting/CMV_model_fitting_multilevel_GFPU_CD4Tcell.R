# this is R code for performing fitting a phenomenological CD4 T cell model to CD4 T cell data for GFPU cohort using bayesian hierarchical modelling
# It calls the stan file "cmv_Tcell_model_multilevel.stan" which implement the Bayesian hirarchical modelling
rm(list=ls())  # clear memory
# ===========  Load R libraries (install them before loading) ====================
library(rstan)
library(tidyverse)
library(bayesplot)
library(deSolve)

# ===========  load clinical data ===============

T_data = read.csv("Tcell_of_GFPU20201021.csv")
filtered_T_data = T_data[(T_data$days %in% c(0:180)),]
for (i in 1:length(filtered_T_data$No)){if (filtered_T_data$CD4[i]==0){filtered_T_data$CD4[i]=1}}

ID_selected = unique(filtered_T_data$No)

selected_T_data = filtered_T_data[(filtered_T_data$No %in% ID_selected),]

nObs_Tdata = length(selected_T_data$CD4)
startT = (1:nObs_Tdata)[!duplicated(selected_T_data$No)]
endT = c(startT[-1] - 1, nObs_Tdata)

# define data list 
data_combined = list(num_pts = 181,
                     nObs_Tdata = length(selected_T_data$CD4),
                     nPar=5,  # number of non-fixed model parameters 
                     nPatients = length(ID_selected),   # number of patients selected
                     time_Tdata = selected_T_data$days,
                     log_Tdata = log(selected_T_data$CD4),
                     startT = (1:nObs_Tdata)[!duplicated(selected_T_data$No)],
                     endT = c(startT[-1] - 1, nObs_Tdata),
                     l = c(0, 1, 1, 0, 0),
                     u = c(10, 500, 500, 10, 100),
                     t0 = 0)

# =========== choose initial estimates ===========

set.seed(12345)   # set random seed for reproducibility

inits = list()
No_of_chains = 4
for (i in 1:No_of_chains){
  inits1 = list(theta = c(runif(1,data_combined$l[1],data_combined$u[1]),
                          runif(1,data_combined$l[2],data_combined$u[2]),
                          runif(1,data_combined$l[3],data_combined$u[3]),
                          runif(1,data_combined$l[4],data_combined$u[4]),
                          runif(1,data_combined$l[5],data_combined$u[5])),
                epsilonT = 1,
                L = diag(data_combined$nPar),    # initial choice for the lower Cholesky factor of the correlation matrix L
                s = matrix(rep(0, data_combined$nPar * data_combined$nPatients), nrow = data_combined$nPar),   # inital choice for the standard multivariate normal distribution s
                omega = c(1,1,1,1,1)/10)
  
  inits[[i]] = inits1
}

options(mc.cores=parallel::detectCores()) # to utilise all cores available in your computer

# model fitting 
fitting_results = stan("cmv_Tcell_model_multilevel.stan",
                       data = data_combined,
                       pars = c("theta", "theta_i"),
                       seed = 202009,  # set random seed for reproducibility
                       iter = 2000,
                       chains = No_of_chains,
                       warmup = 1000,
                       init = inits,
                       control = list(adapt_delta = 0.99, max_treedepth = 10)) 

# show summary result
print(fitting_results)

# save.image(file = "multilevel_fitting_results_GFPU_CMV_Tcell.RData")

# extract posterior samples for population mean parameters
posterior_samples_all = rstan::extract(fitting_results, pars = c("theta"), inc_warmup = TRUE, permuted = FALSE)
posterior_samples_merged_after_burnin = rstan::extract(fitting_results, pars = c("theta"))

# show markov chains
color_scheme_set("brewer-Spectral")
mcmc_trace(posterior_samples_all, n_warmup = 1000,
           facet_args = list(nrow = 2, labeller = label_parsed))


# posterior predictive check
cmv_model = function(t, y, param){
  dydt = param[1]*(t^9/(t^9+param[2]^9))*(param[3]^9/(t^9+param[3]^9))*y+param[4]*(param[5]-y);
  list(c(dydt))
}

# show the model fits of the viral load and CD4 T cell data for individual patients
posterior_individuals = rstan::extract(fitting_results, pars = c("theta_i"))

for (j in 1:length(ID_selected)){  # patient number (not ID)
  
  t_ppc = seq(0, 180, 1)
  
  T_ppc = matrix(, nrow = 4000, ncol = length(t_ppc))
  T_lower_95PI = t_ppc
  T_median_95PI = t_ppc
  T_upper_95PI = t_ppc
  
  for (i in 1:4000){
    y_init = posterior_individuals$theta_i[i,5,j]
    param_fit = c(posterior_individuals$theta_i[i,1,j], posterior_individuals$theta_i[i,2,j],posterior_individuals$theta_i[i,3,j],posterior_individuals$theta_i[i,4,j],posterior_individuals$theta_i[i,5,j])
    model_output = ode(times = t_ppc, y = y_init, func = cmv_model, parms = param_fit, method = "bdf")
    T_ppc[i,] = model_output[,2]
  }
  
  for (i in 1:length(t_ppc)){
    temp1 = quantile(T_ppc[,i], probs = c(0.025, 0.5, 0.975))
    T_lower_95PI[i] = temp1[1]
    T_median_95PI[i] = temp1[2]
    T_upper_95PI[i] = temp1[3]
  }
  
  data_plot_T = data.frame(timeT = data_combined$time_Tdata[startT[j]:endT[j]],
                           data_T = selected_T_data$CD4[startT[j]:endT[j]])
  
  fit_plot = data.frame(time = t_ppc,
                        T_lower_95PI = T_lower_95PI,
                        T_median_95PI = T_median_95PI,
                        T_upper_95PI = T_upper_95PI)
  
  selected_T_data$Patient1 = sapply(selected_T_data$Patient, as.character)
  patient_name = unique(selected_T_data$Patient1[selected_T_data$No %in% ID_selected])
  
  plot_T = ggplot()+
    geom_point(data = data_plot_T, aes(timeT, data_T), size = 3) +
    geom_line(data = fit_plot, aes(time, T_median_95PI)) +
    geom_ribbon(aes(x = fit_plot$time, ymin = T_lower_95PI, ymax = T_upper_95PI), alpha = 0.5) +
    scale_y_continuous(trans='log10') +
    scale_x_continuous(breaks=seq(0,180,30)) +
    coord_cartesian(xlim = c(0,180), ylim = c(1,1e+5)) +
    theme_bw() +
    theme(axis.text=element_text(size=15)) +
    xlab("time (days)") +
    ylab("T")
  
  jpeg(paste0("Fit_ID_", ID_selected[j], ".jpg"))
  print(plot_T)
  dev.off()
}


